defmodule Practice.Calc do

def parse_float(text) do 
  {num,_} = Float.parse(text)
  num
end

def calc(expr) do
 # This should handle + , -, *, / with order of operations,
 #but doesn 't need to handle parens.
 expr = expr | > String.split(~r / \s + /)
 z = multi(expr)
 z
end

def multi(expr) do
 index = Enum.find_index(expr, fn x - > x == "*" end)
 if index == nil do
  z = divide(expr)
  z
 else
  index_1 = Enum.at(expr, index - 1)
  index_2 = Enum.at(expr, index + 1)
  {index_1,_} = Integer.parse(index_1) 
  {index_2,_} = Integer.parse(index_2)
  c = index_1 * index_2
  expr = List.delete_at(expr, index) 
  expr = List.insert_at(expr, index, c) 
  expr = List.delete_at(expr, index - 1) 
  expr = List.delete_at(expr, index)
   multi(expr) 
  end 
end

def divide(expr) do
 index = Enum.find_index(expr, fn x - > x == "*" end)
 if index == nil do
  z = sum(expr)
  z
 else
  index_1 = Enum.at(expr, index - 1)
  index_2 = Enum.at(expr, index + 1)
  {index_1,_} = Integer.parse(index_1) 
  {index_2,_} = Integer.parse(index_2)
  c = index_1 / index_2
  expr = List.delete_at(expr, index) 
  expr = List.insert_at(expr, index, c) 
  expr = List.delete_at(expr, index - 1) 
  expr = List.delete_at(expr, index)
  divide(expr) 
  end 
end

def sum(expr) do
 index = Enum.find_index(expr, fn x - > x == "*" end)
 if index == nil do
  z = sub(expr)
  z
 else
  index_1 = Enum.at(expr, index - 1)
  index_2 = Enum.at(expr, index + 1)
  {index_1,_} = Integer.parse(index_1) 
  {index_2,_} = Integer.parse(index_2)
  c = index_1 + index_2
  expr = List.delete_at(expr, index) 
  expr = List.insert_at(expr, index, c) 
  expr = List.delete_at(expr, index - 1) 
  expr = List.delete_at(expr, index)
   sum(expr) 
  end 
end

def sub(expr) do
 index = Enum.find_index(expr, fn x - > x == "*" end)
 if index == nil do
    expr
 else
  index_1 = Enum.at(expr, index - 1)
  index_2 = Enum.at(expr, index + 1)
  {index_1,_} = Integer.parse(index_1) 
  {index_2,_} = Integer.parse(index_2)
  c = index_1 - index_2
  expr = List.delete_at(expr, index) 
  expr = List.insert_at(expr, index, c) 
  expr = List.delete_at(expr, index - 1) 
  expr = List.delete_at(expr, index)
  sub(expr) 
  end 
end
end